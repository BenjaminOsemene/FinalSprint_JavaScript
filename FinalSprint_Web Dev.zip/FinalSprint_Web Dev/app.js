
// app.js  is the JavaScript file.
// Linking html file(indexF.html) to app.js file  and testing that it works using the console.log statement.

 console.log("Hello, this is my final JavaScript Sprint hope this works!.");


// Read the JSON data(data.json) using the Fetch API method.

fetch('data.json') 
    .then(response => response.json())
    .then(data => {

// Iterate over each record in the data.json using forEach loop.
// displays one key value pair (name and club) to the console.

 data.forEach(record => {
 console.log(`Name: ${record.name}, Club: ${record.club}`);

 // Break out of the loop.
 return;

});
           
// functions to return strings of data describing the contents of the JSON file (data.json).

// Function to find the oldest person.
function getOldestPerson() {
    const oldestPerson = data.reduce((oldest, current) => 
    (current.age > oldest.age ? current : oldest), data[0]);
    return `The oldest person is ${oldestPerson.name} with age ${oldestPerson.age}.`;
}     

// Function to count the number of footballers.
function countFootballers() {
    const footballersCount = data.filter(person => person.isFootballer).length;
    return `There are ${footballersCount} footballers in the group.`;
}

// Function to calculate the average age.
function calculateAverageAge() {
    const totalAge = data.reduce((sum, person) => sum + person.age, 0);
    const averageAge = totalAge / data.length;
    return `The average age is ${averageAge.toFixed(2)}.`;
}

// Function to find the person with the highest rating.
function getHighestRating() {
    const highestRatingPerson = data.reduce((highest, current) => (current.rating > highest.rating ? current : highest), data[0]);
    return `The person with the highest rating is ${highestRatingPerson.name} with a rating of ${highestRatingPerson.rating}.`;
}

// Function to list clubs with footballers.
function getClubsWithFootballers() {
    const clubsWithFootballers = data.filter(person => person.isFootballer && person.club).map(person => person.club);
    return `The clubs with footballers: ${clubsWithFootballers.join(', ')}.`;
}

// Writing the results to the console.
console.log(getOldestPerson());
console.log(countFootballers());
console.log(calculateAverageAge());
console.log(getHighestRating());
console.log(getClubsWithFootballers());


// Writing the results to the browser window.
// getElement method is used to find the html content with id(container) that has been created.
// Then creating a template string that call the functions.

        const containerElement = document.getElementById('container');
        containerElement.innerHTML = `
            <p>${getOldestPerson()}</p>
            <p>${countFootballers()}</p>
            <p>${calculateAverageAge()}</p>
            <p>${getHighestRating()}</p>
            <p>${getClubsWithFootballers()}</p>
        `;
    })
    
    
// Using catch method to capture  any errors that occur while fetching data.json.

.catch(error =>{
    console.error('data.json', error);
    
});